# Fit30

A small self-hosted workout app: four hard 30-minute bodyweight + punching-bag workouts a week,
built for a pull-up/dip station and a free-standing bag (Century BOB). It shows exercise
pictures, runs a round timer, tracks your progress and sends you the day's plan each morning.

- **A: Upper-body power** (pull-ups, dips, plyo/archer push-ups, pike/handstand push-ups, toes to bar, bag finisher)
- **B: Legs and engine** (Bulgarian split squats, pistols, tuck jumps, split jumps, Nordics, hollow holds, bag finisher)
- **C: Bag conditioning** (8–9 two-minute rounds + core)
- **D: Full-body EMOM** (24 minutes, six stations)

Three levels, all built for someone already fit. The level goes up every 12 logged workouts,
or pin it with `LEVEL=`.

**Progress page:** week streak, workouts per week, hours trained, best set per exercise
over time (with new-best alerts), weight and waist, cholesterol lab results, and CSV export.

Exercise photos: [free-exercise-db](https://github.com/yuhonas/free-exercise-db) (public domain),
downloaded once and cached in `./data/img`.

## Install (Le Potato / any Linux box with Docker)

```bash
git clone https://github.com/<you>/fit30.git && cd fit30
cp .env.example .env
nano .env                 # set APP_URL, TZ, NTFY_TOPIC (or other method)
mkdir -p data && sudo chown 1000:1000 data   # container runs as a non-root user
docker compose up -d --build
```

Open `http://<le-potato-ip>:8095` on your phone and use "Add to Home Screen".
Change the port with `HOST_PORT` in `.env`. Check it's running: `docker compose logs -f fit30`.

First build on a Le Potato takes a few minutes. Update later with
`git pull && docker compose up -d --build`.

## Daily message options

| Method  | Cost | Setup |
|---------|------|-------|
| `ntfy`  | Free | Install the ntfy app, subscribe to the topic in `NTFY_TOPIC`. Pick a long random topic name: anyone who knows it can read it on ntfy.sh. |
| `discord` | Free | Server settings → Integrations → Webhooks → copy URL. |
| `twilio` | ~$1–2/mo + per text | Real SMS. US numbers need A2P 10DLC or toll-free verification before texts deliver. |
| `email` | Free | Any SMTP account (for Gmail use an app password). |

Use several at once: `NOTIFY_METHODS=ntfy,discord`. Test from **Settings → Send today's plan now**.

## Notes

- Keep it on your home network. For access away from home, use Tailscale/WireGuard rather than opening a port, and set `APP_PASSWORD`.
- Data lives in `./data` (SQLite + image cache). Back that folder up if you care about the log.
- Edit the workouts in `app/program.py`.
