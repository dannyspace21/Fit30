"""Send the daily plan. Pick one or more methods with NOTIFY_METHODS=ntfy,discord,twilio,email."""
import logging
import os
import smtplib
from email.message import EmailMessage

import requests

log = logging.getLogger("fit30.notify")
TIMEOUT = 15


def _env(name, default=""):
    return os.environ.get(name, default).strip()


def send_ntfy(title, body, url):
    topic = _env("NTFY_TOPIC")
    if not topic:
        raise RuntimeError("NTFY_TOPIC is not set")
    server = _env("NTFY_SERVER", "https://ntfy.sh").rstrip("/")
    headers = {"Title": title.encode("utf-8"), "Tags": "muscle"}
    if url:
        headers["Click"] = url
    token = _env("NTFY_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    r = requests.post(f"{server}/{topic}", data=body.encode("utf-8"), headers=headers, timeout=TIMEOUT)
    r.raise_for_status()


def send_discord(title, body, url):
    hook = _env("DISCORD_WEBHOOK_URL")
    if not hook:
        raise RuntimeError("DISCORD_WEBHOOK_URL is not set")
    r = requests.post(hook, json={"content": f"**{title}**\n{body}"[:1990]}, timeout=TIMEOUT)
    r.raise_for_status()


def send_twilio(title, body, url):
    sid, token = _env("TWILIO_ACCOUNT_SID"), _env("TWILIO_AUTH_TOKEN")
    from_, to = _env("TWILIO_FROM"), _env("SMS_TO")
    if not all([sid, token, from_, to]):
        raise RuntimeError("Set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM and SMS_TO")
    r = requests.post(f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json",
                      data={"From": from_, "To": to, "Body": body[:1500]},
                      auth=(sid, token), timeout=TIMEOUT)
    if r.status_code >= 400:
        raise RuntimeError(f"Twilio said {r.status_code}: {r.text[:300]}")


def send_email(title, body, url):
    host, to = _env("SMTP_HOST"), _env("EMAIL_TO")
    if not host or not to:
        raise RuntimeError("Set SMTP_HOST and EMAIL_TO")
    msg = EmailMessage()
    msg["Subject"], msg["From"], msg["To"] = title, _env("EMAIL_FROM", _env("SMTP_USER")), to
    msg.set_content(body)
    with smtplib.SMTP(host, int(_env("SMTP_PORT", "587")), timeout=TIMEOUT) as s:
        s.starttls()
        if _env("SMTP_USER"):
            s.login(_env("SMTP_USER"), _env("SMTP_PASSWORD"))
        s.send_message(msg)


SENDERS = {"ntfy": send_ntfy, "discord": send_discord, "twilio": send_twilio, "email": send_email}


def methods():
    return [m.strip().lower() for m in _env("NOTIFY_METHODS", "ntfy").split(",") if m.strip()]


def send(title, body, url=""):
    """Returns a list of (method, ok, detail)."""
    results = []
    for m in methods():
        fn = SENDERS.get(m)
        if not fn:
            results.append((m, False, "unknown method"))
            continue
        try:
            fn(title, body, url)
            results.append((m, True, "sent"))
        except Exception as e:  # keep going with the other methods
            log.warning("notify via %s failed: %s", m, e)
            results.append((m, False, str(e)))
    return results
