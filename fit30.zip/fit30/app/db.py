import os
import sqlite3
from contextlib import closing

DB_PATH = os.environ.get("DB_PATH", "/data/fit30.db")


def connect():
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init():
    with closing(connect()) as con, con:
        con.execute("""CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY,
            day TEXT NOT NULL,          -- YYYY-MM-DD local date
            workout TEXT NOT NULL,      -- A/B/C/D
            level INTEGER NOT NULL,
            effort INTEGER,             -- 1 easy .. 5 brutal
            note TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")


def add(day, workout, level, effort=None, note=""):
    with closing(connect()) as con, con:
        con.execute("INSERT INTO sessions(day, workout, level, effort, note) VALUES (?,?,?,?,?)",
                    (day, workout, level, effort, note))


def delete(session_id):
    with closing(connect()) as con, con:
        con.execute("DELETE FROM sessions WHERE id=?", (session_id,))


def between(start, end):
    with closing(connect()) as con:
        return [dict(r) for r in con.execute(
            "SELECT * FROM sessions WHERE day BETWEEN ? AND ? ORDER BY day", (start, end))]


def recent(limit=60):
    with closing(connect()) as con:
        return [dict(r) for r in con.execute(
            "SELECT * FROM sessions ORDER BY day DESC, id DESC LIMIT ?", (limit,))]


def count():
    with closing(connect()) as con:
        return con.execute("SELECT COUNT(*) FROM sessions").fetchone()[0]


# ---------- metrics ----------
def init_metrics():
    with closing(connect()) as con, con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS sets (
            id INTEGER PRIMARY KEY,
            session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
            day TEXT NOT NULL,
            exercise TEXT NOT NULL,     -- key from program.EXERCISES
            value REAL NOT NULL);       -- best set: reps or seconds
        CREATE TABLE IF NOT EXISTS body (
            id INTEGER PRIMARY KEY,
            day TEXT NOT NULL,
            weight REAL,
            waist REAL);
        CREATE TABLE IF NOT EXISTS labs (
            id INTEGER PRIMARY KEY,
            day TEXT NOT NULL,
            total REAL, ldl REAL, hdl REAL, trig REAL);
        """)


def add_session(day, workout, level, effort, note, minutes, best):
    """best: {exercise_key: value}. Returns the session id."""
    with closing(connect()) as con, con:
        cur = con.execute(
            "INSERT INTO sessions(day, workout, level, effort, note) VALUES (?,?,?,?,?)",
            (day, workout, level, effort, note))
        sid = cur.lastrowid
        con.executemany("INSERT INTO sets(session_id, day, exercise, value) VALUES (?,?,?,?)",
                        [(sid, day, k, v) for k, v in best.items()])
        return sid


def delete_session(session_id):
    with closing(connect()) as con, con:
        con.execute("DELETE FROM sets WHERE session_id=?", (session_id,))
        con.execute("DELETE FROM sessions WHERE id=?", (session_id,))


def sets_for(session_ids):
    if not session_ids:
        return {}
    q = ",".join("?" * len(session_ids))
    out = {}
    with closing(connect()) as con:
        for r in con.execute(f"SELECT session_id, exercise, value FROM sets WHERE session_id IN ({q})", session_ids):
            out.setdefault(r["session_id"], []).append(dict(r))
    return out


def exercise_history():
    """{exercise: [(day, best_value_that_day), ...]} oldest first."""
    out = {}
    with closing(connect()) as con:
        for r in con.execute("SELECT exercise, day, MAX(value) v FROM sets GROUP BY exercise, day ORDER BY day"):
            out.setdefault(r["exercise"], []).append((r["day"], r["v"]))
    return out


def all_days():
    with closing(connect()) as con:
        return [r[0] for r in con.execute("SELECT DISTINCT day FROM sessions ORDER BY day")]


def add_row(table, day, **vals):
    assert table in ("body", "labs")
    vals = {k: v for k, v in vals.items() if v is not None}
    if not vals:
        return
    cols = ",".join(["day", *vals])
    with closing(connect()) as con, con:
        con.execute(f"INSERT INTO {table}({cols}) VALUES ({','.join('?' * (len(vals) + 1))})",
                    (day, *vals.values()))


def rows(table):
    assert table in ("body", "labs", "sessions", "sets")
    with closing(connect()) as con:
        return [dict(r) for r in con.execute(f"SELECT * FROM {table} ORDER BY day, id")]


def delete_row(table, rid):
    assert table in ("body", "labs")
    with closing(connect()) as con, con:
        con.execute(f"DELETE FROM {table} WHERE id=?", (rid,))
