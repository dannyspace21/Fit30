(() => {
  if (!window.Chart) return;
  const data = JSON.parse(document.getElementById("chart-data").textContent);
  const css = getComputedStyle(document.documentElement);
  const v = (n) => css.getPropertyValue(n).trim();
  const ink = v("--ink"), muted = v("--muted"), line = v("--line"), signal = v("--signal"),
        go = v("--go"), rest = v("--rest");
  Chart.defaults.color = muted;
  Chart.defaults.borderColor = line;
  Chart.defaults.font.family = v("--body");
  const base = (extra = {}) => ({
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { labels: { boxWidth: 12 } } },
    scales: { y: { beginAtZero: false } }, ...extra,
  });
  const lineSet = (label, values, color) => ({
    label, data: values, borderColor: color, backgroundColor: color, tension: 0.25, spanGaps: true, pointRadius: 4,
  });

  const wk = document.getElementById("c-weeks");
  if (wk) new Chart(wk, {
    type: "bar",
    data: { labels: data.weeks, datasets: [
      { label: "Workouts", data: data.weekCounts,
        backgroundColor: data.weekCounts.map((c) => (c >= data.goal ? go : signal)), borderRadius: 4 },
      { type: "line", label: `Goal (${data.goal})`, data: data.weeks.map(() => data.goal),
        borderColor: ink, borderDash: [5, 4], pointRadius: 0 },
    ] },
    options: base({ scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } }),
  });

  const lc = document.getElementById("c-lift"), pick = document.getElementById("lift-pick");
  if (lc && pick) {
    const lift = (k) => data.lifts[k];
    const chart = new Chart(lc, { type: "line", data: { labels: [], datasets: [] }, options: base() });
    const show = () => {
      const l = lift(pick.value);
      chart.data.labels = l.days;
      chart.data.datasets = [lineSet(`${l.name} (${l.unit === "sec" ? "seconds" : "reps"})`, l.values, signal)];
      chart.update();
    };
    pick.addEventListener("change", show); show();
  }

  const bc = document.getElementById("c-body");
  if (bc) new Chart(bc, {
    type: "line",
    data: { labels: data.body.days, datasets: [
      { ...lineSet("Weight", data.body.weight, ink), yAxisID: "y" },
      { ...lineSet("Waist", data.body.waist, signal), yAxisID: "y1" },
    ] },
    options: base({ scales: { y: { position: "left" }, y1: { position: "right", grid: { drawOnChartArea: false } } } }),
  });

  const lab = document.getElementById("c-labs");
  if (lab) new Chart(lab, {
    type: "line",
    data: { labels: data.labs.days, datasets: [
      lineSet("Total", data.labs.total, ink), lineSet("LDL", data.labs.ldl, rest),
      lineSet("HDL", data.labs.hdl, go), lineSet("Triglycerides", data.labs.trig, signal),
    ] },
    options: base(),
  });
})();
