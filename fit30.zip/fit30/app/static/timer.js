(() => {
  const $ = (id) => document.getElementById(id);
  const panel = $("timer"), clock = $("t-clock"), phaseEl = $("t-phase"),
        roundEl = $("t-round"), nextEl = $("t-next"), toggle = $("t-toggle");
  let cfg = null, phase = "work", round = 1, left = 0, tick = null, ctx = null, lock = null;

  const fmt = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  function beep(freq = 880, ms = 150) {
    try {
      ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.frequency.value = freq; o.connect(g); g.connect(ctx.destination);
      g.gain.setValueAtTime(0.25, ctx.currentTime);
      o.start(); o.stop(ctx.currentTime + ms / 1000);
    } catch (e) { /* no audio */ }
    if (navigator.vibrate) navigator.vibrate(ms);
  }

  async function keepAwake(on) {
    try {
      if (on && "wakeLock" in navigator) lock = await navigator.wakeLock.request("screen");
      else if (lock) { await lock.release(); lock = null; }
    } catch (e) { /* not supported */ }
  }

  function label(r) {
    const l = cfg.labels;
    if (!l.length) return "";
    return l.length === cfg.rounds ? l[r - 1] : l[(r - 1) % l.length];
  }

  function render() {
    clock.textContent = fmt(left);
    panel.className = "timer " + (phase === "done" ? "rest" : phase);
    phaseEl.textContent = phase === "work" ? (label(round) || "Work") : phase === "rest" ? "Rest" : "Done";
    roundEl.textContent = phase === "done" ? "Great work." : `Round ${round} of ${cfg.rounds}`;
    const nxt = round < cfg.rounds ? label(round + 1) : "";
    nextEl.textContent = phase !== "done" && nxt ? `Next: ${nxt}` : "";
  }

  function advance() {
    if (phase === "work" && cfg.rest > 0) { phase = "rest"; left = cfg.rest; beep(440, 400); }
    else if (round < cfg.rounds) { round++; phase = "work"; left = cfg.work; beep(988, 400); }
    else { phase = "done"; left = 0; stop(); beep(660, 700); }
    render();
  }

  function step() {
    left--;
    if (left > 0 && left <= 3) beep(880, 90);
    if (left <= 0) advance(); else render();
  }

  function start() { if (phase === "done") return; tick = setInterval(step, 1000); toggle.textContent = "Pause"; keepAwake(true); }
  function stop() { clearInterval(tick); tick = null; toggle.textContent = phase === "done" ? "Start" : "Resume"; keepAwake(false); }

  document.querySelectorAll(".timer-btn").forEach((b) => b.addEventListener("click", () => {
    cfg = { rounds: +b.dataset.rounds, work: +b.dataset.work, rest: +b.dataset.rest,
            labels: JSON.parse(b.dataset.labels || "[]") };
    $("t-title").textContent = b.dataset.title;
    phase = "work"; round = 1; left = cfg.work;
    toggle.textContent = "Start";
    panel.hidden = false; render();
    beep(1, 1); // unlock audio on iOS from a tap
  }));
  toggle.addEventListener("click", () => (tick ? stop() : start()));
  $("t-skip").addEventListener("click", () => { if (phase !== "done") advance(); });
  $("t-close").addEventListener("click", () => { stop(); panel.hidden = true; });
  document.addEventListener("visibilitychange", () => { if (tick && document.visibilityState === "visible") keepAwake(true); });
})();
