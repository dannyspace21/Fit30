import datetime as dt
import logging
import os
import pathlib
import urllib.parse
import urllib.request
from zoneinfo import ZoneInfo

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from flask import (Flask, Response, abort, flash, redirect, render_template,
                   request, send_file, url_for)

import db
import notify
import csv
import io

from program import DAY_NAMES, WORKOUTS, as_text, resolve, track_unit, tracked_names

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
log = logging.getLogger("fit30")

TZ = ZoneInfo(os.environ.get("TZ", "America/New_York"))
APP_URL = os.environ.get("APP_URL", "").rstrip("/")
NOTIFY_TIME = os.environ.get("NOTIFY_TIME", "06:30")
WEEKLY_GOAL = int(os.environ.get("WEEKLY_GOAL", "4"))
LEVEL_OVERRIDE = os.environ.get("LEVEL", "").strip()
SESSIONS_PER_LEVEL = int(os.environ.get("SESSIONS_PER_LEVEL", "12"))
APP_PASSWORD = os.environ.get("APP_PASSWORD", "")
IMG_CACHE = pathlib.Path(os.environ.get("IMG_CACHE", "/data/img"))
IMG_SOURCE = "https://raw.githubusercontent.com/yuhonas/free-exercise-db/main/exercises"

# e.g. WORKOUT_DAYS=mon,tue,thu,sat -> workouts A,B,C,D in that order
WORKOUT_DAYS = [d.strip().lower()[:3] for d in os.environ.get("WORKOUT_DAYS", "mon,tue,thu,sat").split(",") if d.strip()]
SCHEDULE = {day: "ABCD"[i % 4] for i, day in enumerate(WORKOUT_DAYS)}

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-me")
db.init()
db.init_metrics()
UNITS = os.environ.get("UNITS", "imperial").lower()
W_UNIT, L_UNIT = ("lb", "in") if UNITS == "imperial" else ("kg", "cm")


# ---------- helpers ----------
def today():
    return dt.datetime.now(TZ).date()


def current_level():
    if LEVEL_OVERRIDE.isdigit():
        return max(1, min(3, int(LEVEL_OVERRIDE)))
    return min(3, 1 + db.count() // SESSIONS_PER_LEVEL)


def workout_for(date):
    return SCHEDULE.get(DAY_NAMES[date.weekday()])


def week_view(date):
    monday = date - dt.timedelta(days=date.weekday())
    days = [monday + dt.timedelta(days=i) for i in range(7)]
    done = {}
    for s in db.between(days[0].isoformat(), days[-1].isoformat()):
        done.setdefault(s["day"], []).append(s)
    return [{"date": d, "label": d.strftime("%a"), "workout": workout_for(d),
             "done": d.isoformat() in done, "is_today": d == date} for d in days], len(done)


def demo_link(name):
    return "https://www.youtube.com/results?search_query=" + urllib.parse.quote(f"how to {name} proper form")


EX_NAMES = tracked_names()


@app.template_filter("num")
def num(v):
    return "–" if v is None else (f"{v:g}" if isinstance(v, float) else v)


app.jinja_env.globals.update(demo_link=demo_link, WORKOUTS=WORKOUTS, EX_NAMES=EX_NAMES)


# ---------- optional password ----------
@app.before_request
def basic_auth():
    if not APP_PASSWORD or request.path.startswith("/static"):
        return
    a = request.authorization
    if not a or a.password != APP_PASSWORD:
        return Response("Password required", 401, {"WWW-Authenticate": 'Basic realm="fit30"'})


# ---------- pages ----------
@app.route("/")
def home():
    d = today()
    key = request.args.get("w") or workout_for(d)
    week, done_count = week_view(d)
    plan = resolve(key, current_level()) if key in WORKOUTS else None
    logged_today = any(w["done"] for w in week if w["is_today"])
    return render_template("today.html", plan=plan, week=week, done_count=done_count,
                           goal=WEEKLY_GOAL, date=d, scheduled=workout_for(d),
                           logged_today=logged_today, level=current_level())


@app.route("/workout/<key>")
def workout(key):
    if key not in WORKOUTS:
        abort(404)
    return redirect(url_for("home", w=key))


def _num(v):
    try:
        v = float(v)
        return v if v >= 0 else None
    except (TypeError, ValueError):
        return None


@app.post("/log")
def log_session():
    key = request.form.get("workout", "")
    if key not in WORKOUTS:
        abort(400)
    level = current_level()
    plan = resolve(key, level)
    best = {}
    for ex in plan["tracked"]:
        v = _num(request.form.get("best_" + ex["key"]))
        if v is not None:
            best[ex["key"]] = v
    effort = request.form.get("effort")
    db.add_session(today().isoformat(), key, level, int(effort) if effort else None,
                   request.form.get("note", "")[:500], plan["minutes"], best)
    prs = []
    hist = db.exercise_history()
    for k, v in best.items():
        earlier = [x for d, x in hist.get(k, []) if d < today().isoformat()]
        if earlier and v > max(earlier):
            prs.append(EX_NAMES.get(k, k))
    flash("Workout logged." + (f" New best: {', '.join(prs)}!" if prs else ""))
    return redirect(url_for("progress"))


@app.route("/history")
def history():
    week, done_count = week_view(today())
    sessions = db.recent()
    sets = db.sets_for([x["id"] for x in sessions])
    return render_template("history.html", sessions=sessions, sets=sets, week=week, done_count=done_count,
                           goal=WEEKLY_GOAL, total=db.count(), level=current_level(),
                           per_level=SESSIONS_PER_LEVEL)


@app.post("/history/<int:sid>/delete")
def delete_session(sid):
    db.delete_session(sid)
    flash("Entry removed.")
    return redirect(url_for("history"))


# ---------- progress ----------
def week_start(d):
    return d - dt.timedelta(days=d.weekday())


def weekly_counts(weeks=12):
    days = {dt.date.fromisoformat(x) for x in db.all_days()}
    this = week_start(today())
    out = []
    for i in range(weeks - 1, -1, -1):
        ws = this - dt.timedelta(weeks=i)
        out.append((ws, sum(1 for d in days if ws <= d < ws + dt.timedelta(days=7))))
    return out


def streak():
    """Weeks in a row hitting the goal. This week counts once it's hit."""
    days = {dt.date.fromisoformat(x) for x in db.all_days()}
    ws = week_start(today())
    n = 0
    count = lambda w: sum(1 for d in days if w <= d < w + dt.timedelta(days=7))
    if count(ws) >= WEEKLY_GOAL:
        n += 1
    ws -= dt.timedelta(weeks=1)
    while count(ws) >= WEEKLY_GOAL:
        n += 1
        ws -= dt.timedelta(weeks=1)
    return n


@app.route("/progress")
def progress():
    sessions = db.rows("sessions")
    minutes = sum(resolve(s["workout"], s["level"])["minutes"] for s in sessions if s["workout"] in WORKOUTS)
    month = today().strftime("%Y-%m")
    weekly = weekly_counts()
    hist = db.exercise_history()
    lifts = {k: {"name": EX_NAMES.get(k, k), "unit": track_unit(k),
                 "days": [d for d, _ in v], "values": [x for _, x in v],
                 "best": max(x for _, x in v), "last": v[-1][1]}
             for k, v in hist.items()}
    body, labs = db.rows("body"), db.rows("labs")
    for l in labs:
        l["non_hdl"] = l["total"] - l["hdl"] if l.get("total") is not None and l.get("hdl") is not None else None
    efforts = [s["effort"] for s in sessions[-12:] if s["effort"]]
    stats = {
        "total": len(sessions),
        "streak": streak(),
        "month": sum(1 for s in sessions if s["day"].startswith(month)),
        "hours": round(minutes / 60, 1),
        "avg_effort": round(sum(efforts) / len(efforts), 1) if efforts else None,
    }
    chart = {
        "weeks": [w.strftime("%b %-d") for w, _ in weekly], "weekCounts": [c for _, c in weekly],
        "goal": WEEKLY_GOAL, "lifts": lifts,
        "body": {"days": [b["day"] for b in body], "weight": [b["weight"] for b in body],
                 "waist": [b["waist"] for b in body]},
        "labs": {"days": [l["day"] for l in labs], "total": [l["total"] for l in labs],
                 "ldl": [l["ldl"] for l in labs], "hdl": [l["hdl"] for l in labs],
                 "trig": [l["trig"] for l in labs]},
    }
    return render_template("progress.html", stats=stats, chart=chart, lifts=lifts, body=body, labs=labs,
                           today=today().isoformat(), w_unit=W_UNIT, l_unit=L_UNIT, goal=WEEKLY_GOAL)


def _day(v):
    try:
        return dt.date.fromisoformat(v).isoformat()
    except (TypeError, ValueError):
        return today().isoformat()


@app.post("/progress/body")
def add_body():
    db.add_row("body", _day(request.form.get("day")),
               weight=_num(request.form.get("weight")), waist=_num(request.form.get("waist")))
    flash("Body measurement saved.")
    return redirect(url_for("progress") + "#body")


@app.post("/progress/labs")
def add_labs():
    f = request.form
    db.add_row("labs", _day(f.get("day")), total=_num(f.get("total")), ldl=_num(f.get("ldl")),
               hdl=_num(f.get("hdl")), trig=_num(f.get("trig")))
    flash("Lab results saved.")
    return redirect(url_for("progress") + "#labs")


@app.post("/progress/<table>/<int:rid>/delete")
def delete_metric(table, rid):
    if table not in ("body", "labs"):
        abort(404)
    db.delete_row(table, rid)
    flash("Entry removed.")
    return redirect(url_for("progress") + "#" + table)


@app.route("/export/<table>.csv")
def export(table):
    if table not in ("sessions", "sets", "body", "labs"):
        abort(404)
    data = db.rows(table)
    buf = io.StringIO()
    if data:
        w = csv.DictWriter(buf, fieldnames=list(data[0]))
        w.writeheader()
        w.writerows(data)
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename=fit30-{table}.csv"})


@app.route("/settings")
def settings():
    return render_template("settings.html", methods=notify.methods(), notify_time=NOTIFY_TIME,
                           schedule=SCHEDULE, tz=str(TZ), app_url=APP_URL,
                           level=current_level(), level_fixed=LEVEL_OVERRIDE.isdigit())


@app.post("/notify/test")
def notify_test():
    results = send_daily(force=True)
    for m, ok, detail in results:
        flash(f"{m}: {'sent' if ok else 'failed — ' + detail}")
    if not results:
        flash("No notification methods set. Add NOTIFY_METHODS to your .env file.")
    return redirect(url_for("settings"))


# ---------- exercise images (cached locally after first view) ----------
@app.route("/img/<ex_id>/<int:n>.jpg")
def image(ex_id, n):
    if n not in (0, 1) or not ex_id.replace("_", "").replace("-", "").isalnum():
        abort(404)
    path = IMG_CACHE / ex_id / f"{n}.jpg"
    if not path.exists():
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with urllib.request.urlopen(f"{IMG_SOURCE}/{ex_id}/{n}.jpg", timeout=10) as r:
                path.write_bytes(r.read())
        except Exception as e:
            log.warning("image fetch failed for %s: %s", ex_id, e)
            abort(404)
    return send_file(path, mimetype="image/jpeg", max_age=60 * 60 * 24 * 30)


@app.route("/healthz")
def healthz():
    return "ok"


# ---------- daily message ----------
def send_daily(force=False):
    d = today()
    key = workout_for(d)
    link = APP_URL + "/" if APP_URL else ""
    if key:
        plan = resolve(key, current_level())
        week, done = week_view(d)
        body = as_text(plan, link) + f"\nThis week: {done}/{WEEKLY_GOAL}"
        return notify.send(f"Workout: {plan['name']}", body, link)
    if force or os.environ.get("NOTIFY_REST_DAYS", "false").lower() == "true":
        nxt = next((d + dt.timedelta(days=i) for i in range(1, 8) if workout_for(d + dt.timedelta(days=i))), None)
        body = "Rest day. A 20-minute walk with the stroller still counts for your heart."
        if nxt:
            body += f"\nNext workout: {nxt.strftime('%A')} ({WORKOUTS[workout_for(nxt)]['name']})."
        return notify.send("Rest day", body, link)
    return []


def start_scheduler():
    hh, mm = (int(x) for x in NOTIFY_TIME.split(":"))
    sched = BackgroundScheduler(timezone=TZ)
    sched.add_job(send_daily, CronTrigger(hour=hh, minute=mm, timezone=TZ), id="daily",
                  misfire_grace_time=3600, coalesce=True)
    sched.start()
    log.info("Daily plan scheduled at %s %s on %s", NOTIFY_TIME, TZ, ",".join(SCHEDULE) or "no days")


# Gunicorn runs a single worker (see Dockerfile), so this starts exactly once.
if os.environ.get("DISABLE_SCHEDULER", "").lower() != "true":
    start_scheduler()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
