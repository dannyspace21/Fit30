"""Workout library and the 4-day program.

Images come from the public-domain free-exercise-db project
(https://github.com/yuhonas/free-exercise-db). Exercises with img=None
(boxing moves, burpees, jacks) show cues plus a demo-video search link.

Reps are given per level: index 0 = level 1 (starting out), 1 = level 2, 2 = level 3.
"""

EXERCISES = {
    # --- warm-up ---
    "arm_circles": dict(name="Arm circles", img="Arm_Circles",
        cues="Arms straight out. Small circles growing bigger, then reverse."),
    "inchworm": dict(name="Inchworm", img="Inchworm",
        cues="Fold forward, walk hands out to a plank, walk feet up to hands. Knees soft is fine."),
    "worlds_greatest": dict(name="World's greatest stretch", img="Worlds_Greatest_Stretch",
        cues="Long lunge, same-side elbow down toward the instep, then rotate that arm to the ceiling."),
    "jumping_jacks": dict(name="Jumping jacks", img=None,
        cues="Light and quick on the balls of your feet. Step-jacks if you need low impact."),
    "high_knees": dict(name="High knees", img=None,
        cues="Run in place, knees to hip height, pump the arms. March it if you need to."),

    # --- pull ---
    "pullups": dict(name="Pull-ups", img="Pullups", track="reps",
        cues="Hang with arms straight, pull chest toward the bar, lower under control. No kipping."),
    "negative_pullups": dict(name="Negative pull-ups", img="Pullups",
        cues="Jump or step up so your chin is over the bar, then lower yourself as slowly as you can (3–5 s)."),
    "scap_pullups": dict(name="Scapular pull-ups", img="Scapular_Pull-Up",
        cues="Dead hang, arms straight. Pull shoulder blades down and back to lift a few inches. Pause, lower."),
    "chinups": dict(name="Chin-ups", img="Chin-Up", track="reps",
        cues="Palms facing you, shoulder-width. Usually easier than pull-ups, more biceps."),

    # --- push ---
    "dips": dict(name="Dips", img="Dips_-_Triceps_Version", track="reps",
        cues="Lock out on the bars, lower until upper arms are about parallel to the floor, press up. Shoulders down, not shrugged."),
    "negative_dips": dict(name="Negative dips", img="Dips_-_Triceps_Version",
        cues="Start at the top, lower slowly over 3–5 s, step back up. Skip if your shoulders complain."),
    "pushups": dict(name="Push-ups", img="Pushups", track="reps",
        cues="Hands under shoulders, body in one straight line, chest to a fist's height from the floor."),
    "incline_pushups": dict(name="Incline push-ups", img="Incline_Push-Up",
        cues="Hands on the dip bars, a counter or a couch arm. Same straight body line as a push-up."),
    "decline_pushups": dict(name="Feet-elevated push-ups", img="Push-Ups_With_Feet_Elevated",
        cues="Feet on a chair or step. Harder and more shoulder-focused."),

    # --- legs ---
    "squats": dict(name="Bodyweight squats", img="Bodyweight_Squat",
        cues="Feet shoulder-width, sit hips back and down, chest up, knees track over toes. Full foot on the floor."),
    "jump_squats": dict(name="Jump squats", img="Freehand_Jump_Squat", track="reps",
        cues="Squat, then jump. Land softly and sink straight into the next rep."),
    "reverse_lunges": dict(name="Reverse lunges", img="Crossover_Reverse_Lunge",
        cues="Step back, drop the back knee toward the floor, push through the front heel to stand. Alternate legs."),
    "split_squats": dict(name="Split squats", img="Split_Squats",
        cues="Staggered stance, feet stay planted. Lower straight down, back knee toward the floor."),
    "glute_bridge": dict(name="Glute bridges", img="Butt_Lift_Bridge",
        cues="On your back, knees bent. Drive through heels, squeeze glutes at the top, pause 1 s."),
    "single_leg_bridge": dict(name="Single-leg glute bridges", img="Single_Leg_Glute_Bridge",
        cues="Same as a bridge with one foot lifted. Keep hips level."),

    # --- core ---
    "plank": dict(name="Plank", img="Plank", track="sec",
        cues="Forearms down, body straight from head to heels, squeeze glutes and brace like you're about to be punched."),
    "side_plank": dict(name="Side plank", img="Side_Bridge",
        cues="Elbow under shoulder, hips high. Drop the bottom knee to make it easier."),
    "hanging_knee_raise": dict(name="Knee raises on the dip station", img="Knee_Hip_Raise_On_Parallel_Bars", track="reps",
        cues="Support yourself on the bars, arms locked. Bring knees to chest without swinging, lower slowly."),
    "hanging_leg_raise": dict(name="Hanging leg raises", img="Hanging_Leg_Raise", track="reps",
        cues="Hang from the pull-up bar, raise straight legs to hip height or higher. Control the way down."),
    "superman": dict(name="Superman", img="Superman",
        cues="Face down, lift arms, chest and legs a few inches. Hold 2 s, lower."),
    "mountain_climbers": dict(name="Mountain climbers", img="Mountain_Climbers",
        cues="High plank, drive knees toward the chest one at a time, hips low."),
    "reverse_crunch": dict(name="Reverse crunch", img="Reverse_Crunch",
        cues="On your back, curl knees toward chest and lift hips slightly off the floor. Slow down."),
    "burpees": dict(name="Burpees", img=None, track="reps",
        cues="Squat, hands down, step or jump to plank, back to feet, stand tall. Step it out to go easier."),

    # --- bag (Century BOB) ---
    "bag_jab_cross": dict(name="Bag: jab-cross", img=None, bag=True,
        cues="Stance: lead foot forward, hands up by the chin. Jab with the lead hand, cross with the rear hand while pivoting the back foot. Return hands to the face every punch."),
    "bag_hooks": dict(name="Bag: hooks", img=None, bag=True,
        cues="Elbow bent ~90°, turn hips and the lead foot through the punch. Alternate left and right hooks to BOB's head."),
    "bag_body": dict(name="Bag: body shots", img=None, bag=True,
        cues="Bend the knees to drop level, hooks and straight punches to BOB's torso. Stay low, keep the guard up."),
    "bag_uppercuts": dict(name="Bag: uppercuts", img=None, bag=True,
        cues="Dip slightly, drive up from the legs, palm facing you. Short, tight shots to the chin."),
    "bag_freestyle": dict(name="Bag: freestyle", img=None, bag=True,
        cues="Mix everything: 1-2-3 (jab, cross, hook), move around BOB, keep your feet busy between combos."),
    "bag_flurry": dict(name="Bag: speed flurry", img=None, bag=True,
        cues="Fast, light straight punches non-stop. Speed over power. This is the heart-rate spike."),

    # --- harder variations ---
    "plyo_pushups": dict(name="Plyo push-ups", img="Plyo_Push-up", track="reps",
        cues="Lower under control, then push hard enough that your hands leave the floor. Land soft, go straight into the next rep."),
    "archer_pushups": dict(name="Archer push-ups", img=None, track="reps",
        cues="Hands very wide. Lower toward one hand while the other arm goes straight. Alternate sides; count each side as one."),
    "pike_pushups": dict(name="Pike push-ups", img=None, track="reps",
        cues="Hips high in an upside-down V, lower the top of your head toward the floor between your hands, press back up. Shoulders do the work."),
    "wall_hspu": dict(name="Wall handstand push-ups", img="Handstand_Push-Ups", track="reps",
        cues="Kick up to a handstand facing the wall, lower your head to a folded towel, press out. Partial range is fine to start."),
    "ctb_pullups": dict(name="Chest-to-bar pull-ups", img="Pullups", track="reps",
        cues="Strict pull-ups, but pull until your chest touches the bar. Full hang at the bottom every rep."),
    "burpee_pullups": dict(name="Burpee pull-ups", img=None, track="reps",
        cues="Burpee under the bar, jump straight into a pull-up, drop down, repeat."),
    "hanging_pike": dict(name="Toes to bar", img="Hanging_Pike", track="reps",
        cues="Hang, brace your abs, lift straight legs until toes touch the bar. No swinging."),
    "bulgarian": dict(name="Bulgarian split squats", img="Split_Squats", track="reps",
        cues="Rear foot on a couch or chair behind you. Drop straight down until the front thigh is parallel, drive up through the front heel."),
    "pistol_chair": dict(name="Pistol squat to chair", img="Single-Leg_High_Box_Squat", track="reps",
        cues="One leg out in front, sit down to a chair on one leg, stand back up without the other foot touching."),
    "pistols": dict(name="Pistol squats", img=None, track="reps",
        cues="Full single-leg squat, free leg straight out in front, arms forward for balance. Hold a doorframe if you need to at first."),
    "tuck_jumps": dict(name="Tuck jumps", img="Knee_Tuck_Jump", track="reps",
        cues="Jump explosively and pull your knees to your chest. Land softly on the balls of your feet."),
    "split_jumps": dict(name="Split jumps", img="Split_Jump", track="reps",
        cues="From a lunge, jump and switch legs in the air, land in the opposite lunge. Keep the chest up."),
    "nordic": dict(name="Nordic curl negatives", img="Natural_Glute_Ham_Raise", track="reps",
        cues="Kneel with heels hooked under a couch. Keep hips straight and lower yourself as slowly as possible, catch with your hands, push back up."),
    "hollow_hold": dict(name="Hollow body hold", img=None, track="sec",
        cues="On your back, lower back pressed into the floor, arms and legs straight and a few inches off the ground. Hold."),
    "star_jumps": dict(name="Star jumps", img="Star_Jump",
        cues="Squat down, explode up spreading arms and legs into an X, land soft."),

    # --- cool-down ---
    "hamstring_stretch": dict(name="Hamstring stretch", img="Hamstring_Stretch",
        cues="Hinge at the hips toward a straight leg until you feel a stretch. Breathe slowly."),
    "hip_flexor": dict(name="Kneeling hip flexor stretch", img="Kneeling_Hip_Flexor",
        cues="Half-kneeling, squeeze the back-side glute and shift forward slightly."),
    "chest_stretch": dict(name="Chest and shoulder stretch", img="Chest_And_Front_Of_Shoulder_Stretch",
        cues="Forearm on a doorway or upright of the station, turn gently away."),
    "cat_stretch": dict(name="Cat-cow", img="Cat_Stretch",
        cues="On hands and knees, slowly round then arch your back with your breath."),
    "knees_to_chest": dict(name="Knees to chest", img="Hug_Knees_To_Chest",
        cues="On your back, hug both knees in and rock gently."),
}

# Level 1 is already a real workout for someone fit. Level 3 is rough.
LEVEL_SWAPS = {
    1: {"ctb_pullups": "pullups", "archer_pushups": "plyo_pushups", "wall_hspu": "pike_pushups",
        "pistols": "pistol_chair", "hanging_pike": "hanging_leg_raise", "burpee_pullups": "burpees"},
    2: {"ctb_pullups": "pullups", "wall_hspu": "pike_pushups", "pistols": "pistol_chair"},
    3: {},
}


def item(ex, reps):
    """reps is a str or a 3-tuple per level."""
    return {"ex": ex, "reps": reps}


WARMUP = {"title": "Warm-up", "minutes": 4, "kind": "list", "items": [
    item("jumping_jacks", "45 s"), item("arm_circles", "20 s each way"),
    item("inchworm", "5 reps"), item("worlds_greatest", "3 per side"),
    item("high_knees", "30 s fast"),
]}

COOLDOWN = {"title": "Cool-down", "minutes": 3, "kind": "list", "items": [
    item("hamstring_stretch", "30 s per side"), item("hip_flexor", "30 s per side"),
    item("chest_stretch", "30 s per side"),
]}


def bag_block(timer, moves, title="Bag rounds"):
    """timer: (rounds, work_s, rest_s) or a 3-tuple of those per level."""
    return {"title": title, "kind": "timer", "timer": timer,
            "items": [item(m, "") for m in moves]}


WORKOUTS = {
    "A": {
        "name": "Upper-body power",
        "summary": "Heavy-volume pull, push and core with short rest, then a hard bag finisher.",
        "blocks": [
            WARMUP,
            {"title": "Strength circuit", "minutes": 16, "kind": "circuit",
             "rounds": (4, 5, 5), "rest": "No rest between exercises. 45 s after each round.",
             "items": [
                 item("ctb_pullups", ("8", "10", "8–10 chest to bar")),
                 item("dips", ("12", "15", "20")),
                 item("archer_pushups", ("8", "8 per side", "10 per side")),
                 item("wall_hspu", ("8", "10", "5–8")),
                 item("hanging_pike", ("10", "10", "12")),
             ]},
            bag_block(((6, 45, 15), (7, 45, 15), (8, 40, 10)),
                      ["bag_jab_cross", "bag_hooks", "bag_body", "bag_uppercuts", "bag_flurry", "bag_freestyle", "bag_flurry", "bag_flurry"],
                      title="Bag finisher"),
            COOLDOWN,
        ],
    },
    "B": {
        "name": "Legs and engine",
        "summary": "Single-leg strength and jumps. Your biggest muscles working hardest is the fastest way to spike your heart rate.",
        "blocks": [
            WARMUP,
            {"title": "Strength circuit", "minutes": 16, "kind": "circuit",
             "rounds": (4, 4, 5), "rest": "No rest between exercises. 45–60 s after each round.",
             "items": [
                 item("bulgarian", ("10 per leg", "12 per leg", "15 per leg")),
                 item("tuck_jumps", ("10", "12", "15")),
                 item("pistols", ("5 per leg", "6 per leg", "5–8 per leg")),
                 item("split_jumps", ("16", "20", "24")),
                 item("nordic", ("4", "5", "6")),
                 item("hollow_hold", ("30 s", "40 s", "45 s")),
             ]},
            bag_block(((6, 45, 15), (7, 45, 15), (8, 40, 10)),
                      ["bag_jab_cross", "bag_body", "bag_hooks", "bag_flurry", "bag_freestyle", "bag_uppercuts", "bag_flurry", "bag_flurry"],
                      title="Bag finisher"),
            COOLDOWN,
        ],
    },
    "C": {
        "name": "Bag conditioning",
        "summary": "Long, hard boxing rounds. Mostly cardio, which does the most for cholesterol. Level 3: 5 burpees in every rest.",
        "blocks": [
            WARMUP,
            bag_block(((8, 120, 30), (9, 120, 20), (9, 120, 20)),
                      ["bag_jab_cross", "bag_hooks", "bag_body", "bag_uppercuts", "bag_freestyle",
                       "bag_body", "bag_freestyle", "bag_flurry", "bag_flurry"],
                      title="Bag rounds (2 min on)"),
            {"title": "Core finisher", "minutes": 3, "kind": "list", "items": [
                item("hanging_leg_raise", ("12", "15", "15")),
                item("mountain_climbers", "45 s"),
                item("hollow_hold", ("30 s", "40 s", "45 s")),
            ]},
            COOLDOWN,
        ],
    },
    "D": {
        "name": "Full-body EMOM",
        "summary": "Every minute on the minute for 24 minutes: do the reps, rest whatever's left. If you can't finish in the minute, drop reps.",
        "blocks": [
            {"title": "Warm-up", "minutes": 3, "kind": "list", "items": WARMUP["items"][:4]},
            {"title": "Every minute, on the minute (24 min)", "minutes": 24, "kind": "circuit",
             "rounds": (4, 4, 4),
             "rest": "Start each station at the top of a new minute. Six stations, four rounds.",
             "timer": {"rounds": 24, "work": 60, "rest": 0},
             "items": [
                 item("pullups", ("7", "9", "12")),
                 item("burpee_pullups", ("10", "12", "8")),
                 item("plyo_pushups", ("12", "15", "20")),
                 item("jump_squats", ("15", "20", "25")),
                 item("bag_flurry", ("40 s", "45 s", "50 s")),
                 item("hanging_pike", ("10", "10", "12")),
             ]},
            {"title": "Cool-down", "minutes": 3, "kind": "list", "items": COOLDOWN["items"]},
        ],
    },
}

DAY_NAMES = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]


def _pick(v, level):
    return v[level - 1] if isinstance(v, tuple) else v


def resolve(workout_key, level):
    """Return a workout with level swaps applied and reps/timers picked for the level."""
    level = max(1, min(3, level))
    w = WORKOUTS[workout_key]
    swaps = LEVEL_SWAPS.get(level, {})
    blocks = []
    for b in w["blocks"]:
        nb = {k: v for k, v in b.items() if k != "items"}
        nb["rounds"] = _pick(b.get("rounds"), level)
        t = b.get("timer")
        if isinstance(t, tuple):
            r, wk, rs = _pick(t, level) if isinstance(t[0], tuple) else t
            nb["timer"] = {"rounds": r, "work": wk, "rest": rs}
            nb["minutes"] = round(r * (wk + rs) / 60)
        items = []
        for it in b["items"]:
            key = swaps.get(it["ex"], it["ex"])
            ex = dict(EXERCISES[key], key=key)
            items.append({"ex": ex, "reps": _pick(it["reps"], level)})
        if nb.get("kind") == "timer" and nb.get("timer"):
            items = items[:nb["timer"]["rounds"]]
        nb["items"] = items
        blocks.append(nb)
    total = sum(b["minutes"] for b in blocks)
    tracked = []
    for b in blocks:
        for it in b["items"]:
            ex = it["ex"]
            if ex.get("track") and ex["key"] not in [t["key"] for t in tracked]:
                tracked.append(ex)
    return {"key": workout_key, "name": w["name"], "summary": w["summary"],
            "blocks": blocks, "minutes": total, "level": level, "tracked": tracked}


def tracked_names():
    return {k: v["name"] for k, v in EXERCISES.items() if v.get("track")}


def track_unit(key):
    return EXERCISES.get(key, {}).get("track", "reps")


def as_text(plan, url=""):
    """Short plain-text version for a text message."""
    lines = [f"Today: {plan['name']} ({plan['minutes']} min, level {plan['level']})"]
    for b in plan["blocks"]:
        if b["title"] in ("Warm-up", "Cool-down"):
            lines.append(f"- {b['title']} {b['minutes']} min")
            continue
        head = f"- {b['title']}"
        if b.get("rounds") and b["kind"] == "circuit":
            head += f" x{b['rounds']}"
        lines.append(head + ":")
        if b["kind"] == "timer":
            t = b["timer"]
            lines.append(f"  {t['rounds']} rounds, {t['work']}s on / {t['rest']}s off")
        else:
            for it in b["items"]:
                lines.append(f"  {it['ex']['name']} {it['reps']}".rstrip())
    if url:
        lines.append(f"Pictures + timer: {url}")
    return "\n".join(lines)
